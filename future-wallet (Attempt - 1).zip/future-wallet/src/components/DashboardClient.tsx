"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity, AlertTriangle, BarChart3, ClipboardCopy, Coins, Download,
  Flame, Gauge, LineChart, Play, RefreshCw, Shield, Sparkles
} from "lucide-react";
import { PRESETS } from "@/lib/presets";
import {
  ResponsiveContainer, LineChart as RLineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid,
  BarChart as RBarChart, Bar
} from "recharts";

type ApiOk = { ok: true; output: any };
type ApiErr = { ok: false; error: string; details?: any };
type ApiResp = ApiOk | ApiErr;

function clsx(...x: Array<string | false | undefined | null>) {
  return x.filter(Boolean).join(" ");
}

function toNum(v: any): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function downloadJson(filename: string, data: any) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function copyText(text: string) {
  navigator.clipboard.writeText(text).catch(() => {});
}

function StatCard({
  title, value, sub, icon: Icon, glow = false
}: { title: string; value: string; sub?: string; icon: any; glow?: boolean }) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      className={clsx(
        "rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-md",
        glow && "shadow-neon"
      )}
    >
      <div className="flex items-center gap-3">
        <div className={clsx("rounded-xl p-2 border border-white/10 bg-white/5", glow && "shadow-neon")}>
          <Icon className="h-5 w-5 text-white/80" />
        </div>
        <div className="text-sm text-white/60">{title}</div>
      </div>
      <div className="mt-3 text-2xl font-semibold tracking-tight text-white">{value}</div>
      {sub ? <div className="mt-1 text-xs text-white/50">{sub}</div> : null}
    </motion.div>
  );
}

function SegmentedTabs({
  tabs, active, onChange
}: { tabs: string[]; active: string; onChange: (t: string) => void }) {
  return (
    <div className="inline-flex rounded-2xl border border-white/10 bg-white/5 p-1 backdrop-blur-md">
      {tabs.map(t => (
        <button
          key={t}
          onClick={() => onChange(t)}
          className={clsx(
            "px-4 py-2 text-sm rounded-xl transition",
            active === t ? "bg-white/10 text-white shadow-neon" : "text-white/60 hover:text-white"
          )}
        >
          {t}
        </button>
      ))}
    </div>
  );
}

function ChartCard({
  title, subtitle, children
}: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-md">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-white font-medium">{title}</div>
          {subtitle ? <div className="text-xs text-white/50 mt-1">{subtitle}</div> : null}
        </div>
      </div>
      <div className="mt-3 h-[280px]">
        {children}
      </div>
    </div>
  );
}

export default function DashboardClient() {
  const [presetKey, setPresetKey] = useState(PRESETS[0].key);
  const [scenarioText, setScenarioText] = useState(JSON.stringify(PRESETS[0].scenario, null, 2));
  const [activeTab, setActiveTab] = useState("Builder");
  const [loading, setLoading] = useState(false);
  const [resp, setResp] = useState<ApiResp | null>(null);
  const [latencyMs, setLatencyMs] = useState<number | null>(null);

  const output = (resp && resp.ok) ? resp.output : null;

  const chartData = useMemo(() => {
    if (!output?.sampleSeries?.day) return [];
    const s = output.sampleSeries;

    const len = s.day.length;
    const arr: any[] = [];
    for (let i = 0; i < len; i++) {
      arr.push({
        day: s.day[i],
        balance: toNum(s.balanceBase?.[i]),
        nav: toNum(s.navBase?.[i]),
        walletValue: toNum(s.walletValueBase?.[i]),
        assetValue: toNum(s.assetValueBase?.[i]),
        liquidity: toNum(s.liquidityRatio?.[i]),
        credit: toNum(s.creditScore?.[i]),
        rsi: toNum(s.rsi?.[i]),
        debtPrincipal: toNum(s.debtPrincipal?.[i]),
        taxDue: toNum(s.taxDueBase?.[i]),
        gains: toNum(s.realizedGainsTodayBase?.[i]),
      });
    }
    return arr;
  }, [output]);

  const collapseDensity = useMemo(() => {
    const d = output?.collapseTimingDensity ?? {};
    const keys = Object.keys(d).map(k => Number(k)).filter(n => Number.isFinite(n)).sort((a,b) => a-b);
    return keys.map(k => ({ day: k, prob: toNum(d[String(k)]) }));
  }, [output]);

  function applyPreset(key: string) {
    setPresetKey(key);
    const p = PRESETS.find(x => x.key === key) ?? PRESETS[0];
    setScenarioText(JSON.stringify(p.scenario, null, 2));
  }

  async function runSim() {
    setLoading(true);
    setResp(null);
    setLatencyMs(null);

    let scenario: any;
    try {
      scenario = JSON.parse(scenarioText);
    } catch (e) {
      setResp({ ok: false, error: "Invalid JSON in editor. Fix JSON syntax first." });
      setLoading(false);
      return;
    }

    const t0 = performance.now();
    try {
      const r = await fetch("/api/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(scenario),
      });
      const data = await r.json();
      const t1 = performance.now();
      setLatencyMs(Math.round(t1 - t0));
      setResp(data);
      if (data?.ok) setActiveTab("Overview");
    } catch (e: any) {
      setResp({ ok: false, error: e?.message ?? "Network error" });
    } finally {
      setLoading(false);
    }
  }

  const kpi = useMemo(() => {
    if (!output) return null;

    const cash = `${output.p5FinalBalanceBase} / ${output.expectedFinalBalanceBase} / ${output.p95FinalBalanceBase}`;
    const nav = `${output.p5FinalNavBase} / ${output.expectedFinalNavBase} / ${output.p95FinalNavBase}`;
    const prob = `${Math.round(toNum(output.collapseProbability) * 1000) / 10}%`;

    const last = chartData.length ? chartData[chartData.length - 1] : null;
    const vibe = output.sampleSeries?.vibe?.[output.sampleSeries?.vibe?.length - 1] ?? "—";
    const pet = output.sampleSeries?.pet?.[output.sampleSeries?.pet?.length - 1] ?? "—";

    return { cash, nav, prob, last, vibe, pet };
  }, [output, chartData]);

  return (
    <div className="min-h-screen bg-[#070A12] text-white">
      {/* Background glow */}
      <div className="pointer-events-none fixed inset-0 bg-grid-glow opacity-100" />
      <div className="pointer-events-none fixed inset-0 [background-image:linear-gradient(to_bottom,rgba(7,10,18,.3),rgba(7,10,18,1))]" />

      <div className="relative mx-auto max-w-7xl px-4 py-8">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70 backdrop-blur-md">
              <Sparkles className="h-4 w-4 text-white/70" />
              Future Wallet — Judge Mode Dashboard
            </div>
            <h1 className="mt-3 text-3xl md:text-4xl font-semibold tracking-tight">
              Neon Finance Simulator
            </h1>
            <p className="mt-2 text-white/60 max-w-2xl">
              Deterministic Monte Carlo engine with snapshot/resume, FX, liquidation/tax, RSI, and full explainability charts.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <SegmentedTabs
              tabs={["Builder", "Overview", "Risk", "Breakdown", "Raw"]}
              active={activeTab}
              onChange={setActiveTab}
            />
          </div>
        </div>

        {/* Status strip */}
        <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-md">
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div className="text-sm text-white/70 flex items-center gap-2">
              <Shield className="h-4 w-4 text-white/70" />
              API: <span className="text-white/90">POST /api/simulate</span>
              {latencyMs !== null ? <span className="text-white/50">• {latencyMs}ms</span> : null}
            </div>
            <div className="flex items-center gap-2">
              <button
                className={clsx(
                  "inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm border border-white/10 bg-white/5 hover:bg-white/10 transition",
                  loading && "opacity-60"
                )}
                onClick={() => {
                  try {
                    setScenarioText(JSON.stringify(JSON.parse(scenarioText), null, 2));
                  } catch {}
                }}
                disabled={loading}
              >
                <RefreshCw className="h-4 w-4" />
                Prettify JSON
              </button>

              <button
                className={clsx(
                  "inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm border border-white/10 bg-white/5 hover:bg-white/10 transition shadow-neon",
                  loading && "opacity-60"
                )}
                onClick={runSim}
                disabled={loading}
              >
                <Play className="h-4 w-4" />
                {loading ? "Running..." : "Run Simulation"}
              </button>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Builder always visible */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-md">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-white/80" />
                  <div className="font-medium">Scenario Builder</div>
                </div>
                <select
                  value={presetKey}
                  onChange={(e) => applyPreset(e.target.value)}
                  className="rounded-xl border border-white/10 bg-[#0B1020] px-3 py-2 text-sm text-white/80 outline-none"
                >
                  {PRESETS.map(p => <option key={p.key} value={p.key}>{p.name}</option>)}
                </select>
              </div>

              <div className="mt-3 text-xs text-white/50">
                Edit JSON freely. Presets help judges validate features (FX, volatility, etc).
              </div>

              <textarea
                className="mt-4 h-[420px] w-full rounded-2xl border border-white/10 bg-[#0B1020] p-3 font-mono text-xs text-white/80 outline-none focus:ring-1 focus:ring-white/20"
                value={scenarioText}
                onChange={(e) => setScenarioText(e.target.value)}
                spellCheck={false}
              />

              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  className="inline-flex items-center gap-2 rounded-xl px-3 py-2 text-xs border border-white/10 bg-white/5 hover:bg-white/10 transition"
                  onClick={() => copyText(scenarioText)}
                >
                  <ClipboardCopy className="h-4 w-4" />
                  Copy Scenario JSON
                </button>

                <button
                  className="inline-flex items-center gap-2 rounded-xl px-3 py-2 text-xs border border-white/10 bg-white/5 hover:bg-white/10 transition"
                  onClick={() => downloadJson("scenario.json", JSON.parse(scenarioText))}
                >
                  <Download className="h-4 w-4" />
                  Download Scenario
                </button>

                {output ? (
                  <button
                    className="inline-flex items-center gap-2 rounded-xl px-3 py-2 text-xs border border-white/10 bg-white/5 hover:bg-white/10 transition shadow-neon"
                    onClick={() => downloadJson("output.json", output)}
                  >
                    <Download className="h-4 w-4" />
                    Download Output
                  </button>
                ) : null}
              </div>

              <AnimatePresence>
                {resp && !resp.ok ? (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 6 }}
                    className="mt-4 rounded-2xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200"
                  >
                    <div className="flex items-center gap-2 font-medium">
                      <AlertTriangle className="h-4 w-4" />
                      {resp.error}
                    </div>
                    {resp.details ? (
                      <pre className="mt-2 overflow-auto text-xs text-red-200/80">{JSON.stringify(resp.details, null, 2)}</pre>
                    ) : null}
                  </motion.div>
                ) : null}
              </AnimatePresence>
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-7">
            {!output ? (
              <div className="rounded-2xl border border-white/10 bg-white/5 p-8 backdrop-blur-md">
                <div className="flex items-center gap-3">
                  <div className="rounded-2xl border border-white/10 bg-white/5 p-3 shadow-neon">
                    <Flame className="h-6 w-6 text-white/90" />
                  </div>
                  <div>
                    <div className="text-lg font-medium">Run a simulation to unlock the dashboard</div>
                    <div className="text-sm text-white/60 mt-1">
                      Everything will render: distributions, risk density, RSI, and every daily series + raw JSON.
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <>
                {/* KPI grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <StatCard title="Final Cash (P5 / Mean / P95)" value={kpi?.cash ?? "—"} sub="Strings are exact fixed decimals." icon={Coins} glow />
                  <StatCard title="Final NAV (P5 / Mean / P95)" value={kpi?.nav ?? "—"} sub="This should show Monte Carlo spread." icon={LineChart} glow />
                  <StatCard title="Collapse Probability" value={kpi?.prob ?? "—"} sub="Shows insolvency risk across runs." icon={AlertTriangle} />
                  <StatCard title="Final Vibe + Pet" value={`${kpi?.vibe ?? "—"} • ${kpi?.pet ?? "—"}`} sub="Narrative layer for judges." icon={Sparkles} />
                  <StatCard title="Final Credit Score" value={`${Math.round(kpi?.last?.credit ?? 0)}`} sub="Daily trend shown in Breakdown." icon={Shield} />
                  <StatCard title="Final RSI (stability)" value={`${Math.round(kpi?.last?.rsi ?? 0)}`} sub="0–100, deterministic, volatility-based." icon={Gauge} />
                </div>

                {/* Tabs content */}
                <div className="mt-6 space-y-6">
                  {activeTab === "Builder" ? (
                    <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-md text-white/70">
                      Builder is on the left. Click <span className="text-white">Run Simulation</span> to populate results.
                    </div>
                  ) : null}

                  {activeTab === "Overview" ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <ChartCard title="Balance (base)" subtitle="Daily base cash balance">
                        <ResponsiveContainer width="100%" height="100%">
                          <RLineChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Line type="monotone" dataKey="balance" strokeWidth={2} dot={false} />
                          </RLineChart>
                        </ResponsiveContainer>
                      </ChartCard>

                      <ChartCard title="NAV (base)" subtitle="Assets + cash in base currency">
                        <ResponsiveContainer width="100%" height="100%">
                          <RLineChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Line type="monotone" dataKey="nav" strokeWidth={2} dot={false} />
                          </RLineChart>
                        </ResponsiveContainer>
                      </ChartCard>

                      <ChartCard title="Wallet Value (base)" subtitle="All currencies converted to base (FX correctness)">
                        <ResponsiveContainer width="100%" height="100%">
                          <RLineChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Line type="monotone" dataKey="walletValue" strokeWidth={2} dot={false} />
                          </RLineChart>
                        </ResponsiveContainer>
                      </ChartCard>

                      <ChartCard title="RSI (stability index)" subtitle="0–100, higher = more stable NAV">
                        <ResponsiveContainer width="100%" height="100%">
                          <RLineChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis domain={[0, 100]} stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Line type="monotone" dataKey="rsi" strokeWidth={2} dot={false} />
                          </RLineChart>
                        </ResponsiveContainer>
                      </ChartCard>
                    </div>
                  ) : null}

                  {activeTab === "Risk" ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <ChartCard title="Liquidity Ratio" subtitle="Liquid assets / NAV">
                        <ResponsiveContainer width="100%" height="100%">
                          <RLineChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Line type="monotone" dataKey="liquidity" strokeWidth={2} dot={false} />
                          </RLineChart>
                        </ResponsiveContainer>
                      </ChartCard>

                      <ChartCard title="Collapse Timing Density" subtitle="Histogram of collapse day across runs">
                        <ResponsiveContainer width="100%" height="100%">
                          <RBarChart data={collapseDensity}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Bar dataKey="prob" />
                          </RBarChart>
                        </ResponsiveContainer>
                      </ChartCard>

                      <ChartCard title="Credit Score" subtitle="Daily credit score changes">
                        <ResponsiveContainer width="100%" height="100%">
                          <RLineChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Line type="monotone" dataKey="credit" strokeWidth={2} dot={false} />
                          </RLineChart>
                        </ResponsiveContainer>
                      </ChartCard>

                      <ChartCard title="Asset Value" subtitle="Total market value of assets in base">
                        <ResponsiveContainer width="100%" height="100%">
                          <RLineChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Line type="monotone" dataKey="assetValue" strokeWidth={2} dot={false} />
                          </RLineChart>
                        </ResponsiveContainer>
                      </ChartCard>
                    </div>
                  ) : null}

                  {activeTab === "Breakdown" ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <ChartCard title="Debt Principal" subtitle="Debt principal (scenario currency)">
                        <ResponsiveContainer width="100%" height="100%">
                          <RLineChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Line type="monotone" dataKey="debtPrincipal" strokeWidth={2} dot={false} />
                          </RLineChart>
                        </ResponsiveContainer>
                      </ChartCard>

                      <ChartCard title="Tax Due" subtitle="Unpaid tax due in base">
                        <ResponsiveContainer width="100%" height="100%">
                          <RLineChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Line type="monotone" dataKey="taxDue" strokeWidth={2} dot={false} />
                          </RLineChart>
                        </ResponsiveContainer>
                      </ChartCard>

                      <ChartCard title="Realized Gains (Today)" subtitle="Liquidation gains (base) — spikes explain behavior">
                        <ResponsiveContainer width="100%" height="100%">
                          <RBarChart data={chartData}>
                            <CartesianGrid stroke="rgba(255,255,255,0.08)" />
                            <XAxis dataKey="day" stroke="rgba(255,255,255,0.45)" />
                            <YAxis stroke="rgba(255,255,255,0.45)" />
                            <Tooltip contentStyle={{ background: "#0B1020", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12 }} />
                            <Bar dataKey="gains" />
                          </RBarChart>
                        </ResponsiveContainer>
                      </ChartCard>

                      <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-md">
                        <div className="font-medium flex items-center gap-2">
                          <Activity className="h-5 w-5 text-white/80" />
                          Last-day Snapshot (for judges)
                        </div>
                        <div className="mt-3 grid grid-cols-2 gap-3 text-sm text-white/80">
                          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                            <div className="text-xs text-white/50">Day</div>
                            <div className="mt-1 font-semibold">{chartData.at(-1)?.day ?? "—"}</div>
                          </div>
                          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                            <div className="text-xs text-white/50">Vibe / Pet</div>
                            <div className="mt-1 font-semibold">{kpi?.vibe ?? "—"} / {kpi?.pet ?? "—"}</div>
                          </div>
                          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                            <div className="text-xs text-white/50">Balance</div>
                            <div className="mt-1 font-semibold">{chartData.at(-1)?.balance?.toFixed?.(2) ?? "—"}</div>
                          </div>
                          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                            <div className="text-xs text-white/50">NAV</div>
                            <div className="mt-1 font-semibold">{chartData.at(-1)?.nav?.toFixed?.(2) ?? "—"}</div>
                          </div>
                          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                            <div className="text-xs text-white/50">Liquidity</div>
                            <div className="mt-1 font-semibold">{(chartData.at(-1)?.liquidity ?? 0).toFixed(3)}</div>
                          </div>
                          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                            <div className="text-xs text-white/50">RSI</div>
                            <div className="mt-1 font-semibold">{Math.round(chartData.at(-1)?.rsi ?? 0)}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : null}

                  {activeTab === "Raw" ? (
                    <div className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-md">
                      <div className="flex items-center justify-between gap-3">
                        <div className="font-medium flex items-center gap-2">
                          <Flame className="h-5 w-5 text-white/80" />
                          Raw Output (full)
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            className="inline-flex items-center gap-2 rounded-xl px-3 py-2 text-xs border border-white/10 bg-white/5 hover:bg-white/10 transition"
                            onClick={() => copyText(JSON.stringify(output, null, 2))}
                          >
                            <ClipboardCopy className="h-4 w-4" />
                            Copy
                          </button>
                          <button
                            className="inline-flex items-center gap-2 rounded-xl px-3 py-2 text-xs border border-white/10 bg-white/5 hover:bg-white/10 transition shadow-neon"
                            onClick={() => downloadJson("output.json", output)}
                          >
                            <Download className="h-4 w-4" />
                            Download
                          </button>
                        </div>
                      </div>
                      <pre className="mt-4 max-h-[520px] overflow-auto rounded-2xl border border-white/10 bg-[#0B1020] p-3 text-xs text-white/80">
                        {JSON.stringify(output, null, 2)}
                      </pre>
                    </div>
                  ) : null}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-10 text-center text-xs text-white/40">
          Built for judges: deterministic engine + full metrics + explainability series + raw packet export.
        </div>
      </div>
    </div>
  );
}
