'use client';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface Snapshot {
  date: string;
  balance: number;
  netWorth: number;
}

export function TrajectoryChart({ data }: { data: Snapshot[] }) {
  return (
    <div className="h-[400px] w-full bg-black/40 backdrop-blur-md border border-white/10 rounded-2xl p-4">
      <h3 className="text-gray-400 uppercase tracking-widest text-xs font-bold mb-4">Projected Trajectory (3 Years)</h3>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorNetWorth" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
            </linearGradient>
            <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
          <XAxis 
            dataKey="date" 
            tickFormatter={(str) => new Date(str).getFullYear().toString()} 
            stroke="#555" 
            tick={{fill: '#555'}}
          />
          <YAxis 
            stroke="#555" 
            tickFormatter={(val) => `$${val/1000}k`} 
            tick={{fill: '#555'}}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#000', borderColor: '#333', color: '#fff' }}
            formatter={(value: number) => [`$${value.toFixed(2)}`, '']}
          />
          <Area 
            type="monotone" 
            dataKey="netWorth" 
            stroke="#8b5cf6" 
            fillOpacity={1} 
            fill="url(#colorNetWorth)" 
            name="Net Worth"
          />
          <Area 
            type="monotone" 
            dataKey="balance" 
            stroke="#10b981" 
            fillOpacity={1} 
            fill="url(#colorBalance)" 
            name="Liquid Cash"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}