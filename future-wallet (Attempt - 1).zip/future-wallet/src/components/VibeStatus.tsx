import { motion } from "framer-motion";
import { Activity, Skull, Heart, Zap } from "lucide-react";

interface VibeProps {
  petState: 'Happy' | 'Sad' | 'Sick' | 'Dead';
  financialVibe: string;
  creditScore: number;
  collapseProb: number;
}

export function VibeStatus({ petState, financialVibe, creditScore, collapseProb }: VibeProps) {
  // Map Pet State to Emojis/Icons
  const getPetIcon = () => {
    switch (petState) {
      case 'Happy': return <Heart className="w-16 h-16 text-pink-500 drop-shadow-glow" />;
      case 'Sad': return <Activity className="w-16 h-16 text-blue-400" />;
      case 'Sick': return <Zap className="w-16 h-16 text-yellow-400 animate-pulse" />;
      case 'Dead': return <Skull className="w-16 h-16 text-gray-500" />;
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-xl border border-white/10 p-6 rounded-2xl flex flex-col gap-6">
      <h3 className="text-gray-400 uppercase tracking-widest text-xs font-bold">System Health</h3>
      
      {/* The Pet State - Centerpiece */}
      <div className="flex items-center justify-between">
        <div className="relative">
          <motion.div 
            animate={{ scale: [1, 1.1, 1] }} 
            transition={{ repeat: Infinity, duration: 2 }}
          >
            {getPetIcon()}
          </motion.div>
          <div className="absolute -bottom-2 -right-2 bg-white text-black text-xs font-bold px-2 py-0.5 rounded-full">
            {petState}
          </div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-black text-white">{financialVibe}</div>
          <div className="text-xs text-gray-500">Current Vibe</div>
        </div>
      </div>

      {/* Risk Metrics */}
      <div className="grid grid-cols-2 gap-4 mt-2">
        <div className="bg-white/5 p-3 rounded-lg">
          <div className="text-xs text-gray-400">Collapse Risk</div>
          <div className={`text-xl font-bold ${collapseProb > 0.5 ? 'text-red-500' : 'text-green-500'}`}>
            {(collapseProb * 100).toFixed(1)}%
          </div>
        </div>
        <div className="bg-white/5 p-3 rounded-lg">
          <div className="text-xs text-gray-400">Credit Score</div>
          <div className="text-xl font-bold text-indigo-400">{creditScore}</div>
        </div>
      </div>
    </div>
  );
}