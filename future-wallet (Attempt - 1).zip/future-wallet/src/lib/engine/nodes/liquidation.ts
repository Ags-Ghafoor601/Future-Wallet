import { Node, Delta } from "./node";
import { EngineState } from "../types";
import { addToWallet, mulFixed, divFixed, parseFixedDecimal } from "../fixed";

export function LiquidationNode(): Node {
  return {
    id: "liquidation",
    dependsOn: ["assets"],

    compute(prev: EngineState): Delta {
      const base = prev.baseCurrency;
      const wallet = { ...prev.wallet };
      const assets = prev.assets.map(a => ({ ...a }));

      let baseCash = wallet[base] ?? 0n;
      if (baseCash >= 0n) {
        // No deficit, no liquidation
        return { wallet, assets };
      }

      let realized = 0n;

      // Deterministic liquidation order
      const order = assets.slice().sort((x, y) => x.name.localeCompare(y.name));

      for (const a of order) {
        if (baseCash >= 0n) break;

        if (!a.liquid) continue;
        if (prev.day < a.lockUntilDay) continue;
        if (a.quantity <= 0n) continue;

        const penaltyFactor = parseFixedDecimal("1.0") - a.salePenalty;
        const effectivePrice = mulFixed(a.price, penaltyFactor);
        if (effectivePrice <= 0n) continue;

        const deficit = -baseCash;

        // qtyNeeded = deficit / effectivePrice (fixed-point trunc)
        let qtyNeeded = divFixed(deficit, effectivePrice);

        // ensure we actually sell something (tiny minimum) if deficit exists
        if (qtyNeeded <= 0n) qtyNeeded = parseFixedDecimal("0.000001");

        const sellQty = qtyNeeded >= a.quantity ? a.quantity : qtyNeeded;

        const proceeds = mulFixed(sellQty, effectivePrice);
        addToWallet(wallet, base, proceeds);
        baseCash += proceeds;

        // realized gain (simple model)
        const gainPerUnit = a.price - a.avgCost;
        realized += mulFixed(sellQty, gainPerUnit);

        a.quantity -= sellQty;
      }

      // Keep assets deterministically ordered
      const assetsSorted = assets.slice().sort((x, y) => x.name.localeCompare(y.name));

      return {
        wallet,
        assets: assetsSorted,
        realizedGainsTodayBase: (prev.realizedGainsTodayBase ?? 0n) + realized,
      };
    },
  };
}
