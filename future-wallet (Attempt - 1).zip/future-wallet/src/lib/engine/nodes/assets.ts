import { Node, Delta } from "./node";
import { EngineState, Scenario } from "../types";
import { addToWallet, mulFixed, parseFixedDecimal, divFixed } from "../fixed";
import { randInt } from "../prng";

function clamp(min: number, x: number, max: number) {
  return Math.max(min, Math.min(max, x));
}



export function AssetsNode(scn: Scenario): Node {
  const volMap: Record<string, bigint> = {};
for (const a of scn.assets ?? []) {
  volMap[a.name] = parseFixedDecimal(a.volatility);
}
  return {
    id: "assets",
    dependsOn: ["debt"],

    compute(prev: EngineState, ctx): Delta {
      const assets = prev.assets.map((a) => ({ ...a }));
      const wallet = { ...prev.wallet };

      // Update prices deterministically (uniform move in [-vol..+vol])
      let prngState = prev.prngState;

      for (const a of assets) {
        const vol = volMap[a.name] ?? 0n;
        // random integer in [-1000..1000], convert to fraction = r/1000 * vol
        const r = randInt(prngState, -1000, 1000);
        prngState = r.state;

       // r.value is in [-1000..1000]
// rFixed represents (r/1000) in fixed-point
const rFixed = (BigInt(r.value) * 1_000_000n) / 1000n; // SCALE/1000 without floats
const move = mulFixed(vol, rFixed);


        // price = price * (1 + move)
        const one = parseFixedDecimal("1.0");
        const factor = one + move;
        a.price = mulFixed(a.price, factor);

        if (a.price < 0n) a.price = 0n;
      }

      // Forced liquidation if base currency cash < 0 at end of day
      const base = prev.baseCurrency;
      let baseCash = wallet[base] ?? 0n;

      if (baseCash < 0n) {
        // deterministic liquidation order: asset name asc
        const order = assets.slice().sort((x, y) => x.name.localeCompare(y.name));

        for (const a of order) {
          if (baseCash >= 0n) break;
          if (!a.liquid) continue;
          if (prev.day < a.lockUntilDay) continue;
          if (a.quantity <= 0n) continue;

          // Need to sell enough to cover deficit (plus penalty)
          const penaltyFactor = parseFixedDecimal("1.0") - a.salePenalty;
          const effectivePrice = mulFixed(a.price, penaltyFactor);
          if (effectivePrice <= 0n) continue;

          const deficit = -baseCash;

          // unitsNeeded = deficit / effectivePrice (ceil in fixed units)
          // We'll do deterministic ceil by: (deficit + effectivePrice - 1) / effectivePrice in integer space.
          // But these are fixed-point; do ceil on fixed quantities:
          const unitsNeeded = divFixed(deficit, effectivePrice);
          const sellQty = unitsNeeded >= a.quantity ? a.quantity : unitsNeeded;

          if (sellQty > 0n) {
            // proceeds = sellQty * effectivePrice
            const proceeds = mulFixed(sellQty, effectivePrice);
            addToWallet(wallet, base, proceeds);
            baseCash += proceeds;

            // realized gain = (sellQty*(price - avgCost))  (before penalty for MVP)
            // We'll compute in engine (to keep tax in one place). Here we track it in state field.
            // Simplify: realized gains tracked elsewhere; this node doesn’t add it.
            a.quantity -= sellQty;
          }
        }
      }

      return { assets, wallet, prngState };
    },
  };
}
