import {
  AggregateOutput,
  EngineState,
  Scenario,
  SimulationResult,
  SimulationSeries,
  SCALE,
  AssetLot,
} from "./types";
import { parseFixedDecimal, formatFixedDecimal, addToWallet, mulFixed, divFixed } from "./fixed";
import { topoSortStable } from "./dag";
import { randU32 } from "./prng";

import { CashflowNode } from "./nodes/cashflow";
import { DebtNode } from "./nodes/debt";
import { AssetsNode } from "./nodes/assets";
import { TaxNode } from "./nodes/tax";
import { LiquidationNode } from "./nodes/liquidation";
import { MetricsNode } from "./nodes/metrics";
import type { Node, Delta } from "./nodes/node";

const RSI_WINDOW = 7;
const RSI_K = 5000n; // tuning constant; higher => RSI drops faster

function absBig(x: bigint): bigint {
  return x < 0n ? -x : x;
}

// returns fixed-point ratio (scaled 1e6) for (a/b)
function ratioFixed(a: bigint, b: bigint): bigint {
  if (b === 0n) return 0n;
  return (a * 1_000_000n) / b;
}

// Compute RSI 0..100 from avgAbsReturn (fixed 1e6)
function rsiFromAvgAbs(avgAbsReturn: bigint): number {
  // scoreFixed = 100 - (K * avgAbsReturn)/1e6
  const drop = (RSI_K * avgAbsReturn) / 1_000_000n;
  let score = 100n - drop;
  if (score < 0n) score = 0n;
  if (score > 100n) score = 100n;
  return Number(score);
}


function fxLookup(scn: Scenario, day: number, pair: string): string | null {
  const table = scn.fxTableDaily[day] ?? scn.fxTableDaily[0] ?? {};
  return (table as any)[pair] ?? null;
}

function walletValueInBase(scn: Scenario, day: number, wallet: Record<string, bigint>, base: string): bigint {
  let total = 0n;
  for (const ccy of Object.keys(wallet).sort()) {
    const amt = wallet[ccy] ?? 0n;
    total += (ccy === base) ? amt : convert(scn, day, amt, ccy, base);
  }
  return total;
}

// Convert money from `from` currency to `to` currency at given day using FX table.
// Uses pair "FROM/TO" if present; else tries inverse "TO/FROM".
function convert(
  scn: Scenario,
  day: number,
  amount: bigint,
  from: string,
  to: string
): bigint {
  if (from === to) return amount;
  const p1 = `${from}/${to}`;
  const r1 = fxLookup(scn, day, p1);
  if (r1) {
    const rate = parseFixedDecimal(r1); // to per from
    return mulFixed(amount, rate);      // amount(from) * rate = amount(to)
  }
  const p2 = `${to}/${from}`;
  const r2 = fxLookup(scn, day, p2);
  if (r2) {
    const inv = parseFixedDecimal(r2);  // from per to
    // amount(to) = amount(from) / inv
    return divFixed(amount, inv);
  }
  throw new Error(`Missing FX rate for ${from}<->${to} on day ${day}`);
}

// Compute base NAV and liquidity ratio (liquid assets / total nav)
function computeNav(state: EngineState): { nav: bigint; assetValue: bigint; liquidityRatio: number } {
  const base = state.baseCurrency;
  const baseCash = state.wallet[base] ?? 0n;

  let assetsValue = 0n;
  let liquidValue = 0n;

  for (const a of state.assets) {
    const v = mulFixed(a.quantity, a.price);
    assetsValue += v;
    if (a.liquid && state.day >= a.lockUntilDay) liquidValue += v;
  }

  const nav = baseCash + assetsValue;

  // ✅ BigInt-safe liquidity ratio:
  // ratioFixed = liquid/nav scaled to 1e6
  const ratioFixed = nav === 0n ? 0n : (liquidValue * 1_000_000n) / nav;
  const ratio = Number(ratioFixed) / 1_000_000;

  return { nav, assetValue: assetsValue, liquidityRatio: isFinite(ratio) ? ratio : 0 };
}


// Deterministic forced liquidation that also records realized gains for TaxNode.
/*function forcedLiquidationWithGains(state: EngineState): EngineState {
  const base = state.baseCurrency;
  let baseCash = state.wallet[base] ?? 0n;
  if (baseCash >= 0n) return state;

  const assets = state.assets.map(a => ({ ...a }));
  const wallet = { ...state.wallet };

  let realized = 0n;

  const order = assets.slice().sort((x, y) => x.name.localeCompare(y.name));
  for (const a of order) {
    if (baseCash >= 0n) break;
    if (!a.liquid) continue;
    if (state.day < a.lockUntilDay) continue;
    if (a.quantity <= 0n) continue;

    const penaltyFactor = parseFixedDecimal("1.0") - a.salePenalty;
    const effectivePrice = mulFixed(a.price, penaltyFactor);
    if (effectivePrice <= 0n) continue;

    const deficit = -baseCash;

    // qtyNeeded = deficit / effectivePrice (ceil-ish handled by trunc + min)
    let qtyNeeded = divFixed(deficit, effectivePrice);
    if (qtyNeeded <= 0n) qtyNeeded = parseFixedDecimal("0.000001"); // minimal sell
    const sellQty = qtyNeeded >= a.quantity ? a.quantity : qtyNeeded;

    // proceeds
    const proceeds = mulFixed(sellQty, effectivePrice);
    addToWallet(wallet, base, proceeds);
    baseCash += proceeds;

    // realized gains (ignore penalty for cost basis; good enough for MVP)
    const gainPerUnit = a.price - a.avgCost;
    const gain = mulFixed(sellQty, gainPerUnit);
    realized += gain;

    a.quantity -= sellQty;
  }

  // Rebuild assets array in deterministic order (name asc)
  const assetsSorted = assets.slice().sort((x, y) => x.name.localeCompare(y.name));

  return {
    ...state,
    wallet,
    assets: assetsSorted,
    realizedGainsTodayBase: state.realizedGainsTodayBase + realized,
  };
}*/

function initialStateFromScenario(scn: Scenario, runSeed: number): EngineState {
  const wallet: Record<string, bigint> = {};
  wallet[scn.baseCurrency] = 0n;

  const assets: AssetLot[] = (scn.assets ?? []).map((a) => ({
    name: a.name,
    quantity: parseFixedDecimal(a.quantity),
    avgCost: parseFixedDecimal(a.priceStart),
    price: parseFixedDecimal(a.priceStart),
    liquid: a.liquid,
    lockUntilDay: a.lockUntilDay ?? 0,
    salePenalty: parseFixedDecimal(a.salePenalty ?? "0.005"),
  })).sort((x, y) => x.name.localeCompare(y.name));

  const debt = scn.debt
    ? {
        principal: parseFixedDecimal(scn.debt.principal),
        apr: parseFixedDecimal(scn.debt.apr),
        minPayDaily: parseFixedDecimal(scn.debt.minPayDaily),
        currency: scn.debt.currency,
        daysLate: 0,
        onTimePayments: 0,
      }
    : undefined;

  return {
    day: 0,
    baseCurrency: scn.baseCurrency,
    wallet,
    assets,
    debt,
    realizedGainsTodayBase: 0n,
    taxDueBase: 0n,
    prngState: runSeed >>> 0,
    metrics: {
      creditScore: 650,
      shockCount30: 0,
      lastBalanceBase: 0n,
      vibe: "Cautious",
      pet: "Turtle",
    },
  };
}

function buildNodes(scn: Scenario): Node[] {
  // minimal deterministic DAG
  return [
    CashflowNode(scn),
    DebtNode(scn),
    AssetsNode(scn),
    LiquidationNode(),
    TaxNode(scn),
    MetricsNode(),
  ];
}

function applyDelta(prev: EngineState, delta: Delta): EngineState {
  // two-phase commit: merge shallow copies
  return {
    ...prev,
    ...delta,
    wallet: delta.wallet ?? prev.wallet,
    assets: delta.assets ?? prev.assets,
    debt: delta.debt ?? prev.debt,
    metrics: delta.metrics ?? prev.metrics,
    prngState: delta.prngState ?? prev.prngState,
    realizedGainsTodayBase: delta.realizedGainsTodayBase ?? prev.realizedGainsTodayBase,
    taxDueBase: delta.taxDueBase ?? prev.taxDueBase,
  };
}

function simulateFromState(
  scn: Scenario,
  init: EngineState,
  startDay: number,
  endDay: number
): { finalState: EngineState; series: SimulationSeries; collapseDay: number | null } {
  const nodes = buildNodes(scn);
  const order = topoSortStable(nodes.map(n => ({ id: n.id, dependsOn: n.dependsOn })));
  const nodeMap: Record<string, Node> = {};
  for (const n of nodes) nodeMap[n.id] = n;

  let state = { ...init };
  let collapseDay: number | null = null;

  // init series
  const series: SimulationSeries = {
    day: [],
    balanceBase: [],
    navBase: [],
    liquidityRatio: [],
    creditScore: [],
    vibe: [],
    pet: [],
    walletValueBase: [], 
    assetValueBase: [],
    debtPrincipal: [],
    realizedGainsTodayBase: [],
    taxDueBase: [],
    rsi: [],
  };

  let prevNav: bigint | null = null;
  const absReturns: bigint[] = [];

  for (let day = startDay; day < endDay; day++) {
    state = { ...state, day, realizedGainsTodayBase: 0n };

    const fxForDay = (pair: string) => {
      const t = scn.fxTableDaily[day] ?? scn.fxTableDaily[0] ?? {};
      return (t as any)[pair] ?? null;
    };

    let next = state;
    for (const id of order) {
      const node = nodeMap[id];
      const delta = node.compute(next, { fxForDay });
      next = applyDelta(next, delta);
    }

    const baseBal = next.wallet[next.baseCurrency] ?? 0n;

    if (collapseDay === null && baseBal < parseFixedDecimal("-1000.0")) {
      collapseDay = day;
    }

    const { nav, assetValue, liquidityRatio } = computeNav(next);

    // RSI calc
    let rsiVal = 100;
    if (prevNav !== null && prevNav !== 0n) {
      const diff = nav - prevNav;
      const ret = absBig(ratioFixed(diff, prevNav));
      absReturns.push(ret);
      if (absReturns.length > RSI_WINDOW) absReturns.shift();
      const sum = absReturns.reduce((a, b) => a + b, 0n);
      const avg = sum / BigInt(absReturns.length);
      rsiVal = rsiFromAvgAbs(avg);
    }
    prevNav = nav;

    // Push series
    series.day.push(day);
    series.balanceBase.push(formatFixedDecimal(baseBal));
    series.navBase.push(formatFixedDecimal(nav));
    series.liquidityRatio.push(liquidityRatio);
    series.creditScore.push(next.metrics.creditScore);
    series.vibe.push(next.metrics.vibe);
    const wv = walletValueInBase(scn, day, next.wallet, next.baseCurrency);
    series.walletValueBase.push(formatFixedDecimal(wv));
    series.pet.push(next.metrics.pet);

    series.assetValueBase.push(formatFixedDecimal(assetValue));
    series.debtPrincipal.push(next.debt ? formatFixedDecimal(next.debt.principal) : "0.000000");
    series.realizedGainsTodayBase.push(formatFixedDecimal(next.realizedGainsTodayBase));
    series.taxDueBase.push(formatFixedDecimal(next.taxDueBase));
    series.rsi.push(rsiVal);

    state = next;
  }

  return { finalState: state, series, collapseDay };
}

export function runSingleSimulation(scn: Scenario, runIndex: number): SimulationResult {
  const runSeed = (scn.seed + runIndex) >>> 0;
  const init = initialStateFromScenario(scn, runSeed);

  const sim = simulateFromState(scn, init, 0, scn.horizonDays);

  const finalBal = sim.finalState.wallet[sim.finalState.baseCurrency] ?? 0n;
  const { nav: finalNav } = computeNav(sim.finalState);

  return {
    series: sim.series,
    finalBalanceBase: formatFixedDecimal(finalBal),
    finalNavBase: formatFixedDecimal(finalNav),
    collapseDay: sim.collapseDay,
  };
}
export { simulateFromState, initialStateFromScenario, computeNav };

export function runAggregate(scn: Scenario): AggregateOutput {
  const results: SimulationResult[] = [];
  for (let i = 0; i < scn.runs; i++) {
    results.push(runSingleSimulation(scn, i));
  }

  const rsiFinals = results.map(r => r.series.rsi[r.series.rsi.length - 1] ?? 0);
const rsiSorted = rsiFinals.slice().sort((a, b) => a - b);

const rsiMean = Math.round(rsiSorted.reduce((a, b) => a + b, 0) / rsiSorted.length);
const rsiP5 = rsiSorted[Math.floor(0.05 * (rsiSorted.length - 1))];
const rsiP95 = rsiSorted[Math.floor(0.95 * (rsiSorted.length - 1))];

  // final balances -> sort deterministically
  const finals = results.map(r => parseFixedDecimal(r.finalBalanceBase));
  const sorted = finals.slice().sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));

  const mean = sorted.reduce((acc, x) => acc + x, 0n) / BigInt(sorted.length);

  const p5 = sorted[Math.floor(0.05 * (sorted.length - 1))];
  const p95 = sorted[Math.floor(0.95 * (sorted.length - 1))];

  // ------
  const finalNavs = results.map(r => parseFixedDecimal(r.finalNavBase));
const navSorted = finalNavs.slice().sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));

const navMean = navSorted.reduce((acc, x) => acc + x, 0n) / BigInt(navSorted.length);
const navP5 = navSorted[Math.floor(0.05 * (navSorted.length - 1))];
const navP95 = navSorted[Math.floor(0.95 * (navSorted.length - 1))];


  // collapse stats
  const collapseCount = results.filter(r => r.collapseDay !== null).length;
  const density: Record<number, number> = {};
  for (const r of results) {
    if (r.collapseDay !== null) {
      density[r.collapseDay] = (density[r.collapseDay] ?? 0) + 1;
    }
  }

 const sample = results[0];

return {
  expectedFinalBalanceBase: formatFixedDecimal(mean),
  p5FinalBalanceBase: formatFixedDecimal(p5),
  p95FinalBalanceBase: formatFixedDecimal(p95),

  expectedFinalNavBase: formatFixedDecimal(navMean),
  p5FinalNavBase: formatFixedDecimal(navP5),
  p95FinalNavBase: formatFixedDecimal(navP95),
  expectedFinalRsi: rsiMean,
p5FinalRsi: rsiP5,
p95FinalRsi: rsiP95,
sampleFinalRsi: results[0].series.rsi[results[0].series.rsi.length - 1] ?? 0,


  collapseProbability: collapseCount / results.length,
  collapseTimingDensity: density,

  sampleSeries: sample.series,

  // ✅ NEW
  sampleFinalBalanceBase: sample.finalBalanceBase,
  sampleFinalNavBase: sample.finalNavBase,
  sampleCollapseDay: sample.collapseDay,
};


}
