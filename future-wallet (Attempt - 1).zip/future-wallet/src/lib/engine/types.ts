export const SCALE = 1_000_000n; // 1e6 fixed-point scale

export type CurrencyCode = string; // "USD", "PKR", ...

export type Money = bigint; // fixed-point microunits

export type FxPair = `${string}/${string}`; // "USD/PKR"

export type Scenario = {
  baseCurrency: CurrencyCode;
  horizonDays: number;
  runs: number; // Monte Carlo runs
  seed: number;

  // daily incomes/expenses (same every day for MVP)
  incomeDaily: { amount: string; currency: CurrencyCode }[];
  expenseDaily: { amount: string; currency: CurrencyCode }[];

  // FX rates: day -> { "USD/PKR": "278.500000" }
  fxTableDaily: Record<number, Record<FxPair, string>>;

  debt?: {
    principal: string; // in debt.currency
    apr: string; // e.g. "0.24" for 24%
    minPayDaily: string;
    currency: CurrencyCode;
  };

  assets?: Array<{
    name: string;
    quantity: string;     // units (supports decimals)
    priceStart: string;   // in baseCurrency per unit
    volatility: string;   // daily max move as fraction, e.g. "0.02" = +/-2%
    liquid: boolean;
    lockUntilDay?: number;
    salePenalty?: string; // e.g. "0.005" = 0.5%
  }>;

  tax?: {
    // brackets in base currency (gains only), very simple MVP
    brackets?: Array<{ upTo: string; rate: string }>;
  };
};

export type EngineConfig = {
  scale: bigint; // SCALE
};

export type Wallet = Record<CurrencyCode, Money>;

export type AssetLot = {
  name: string;
  quantity: Money;       // fixed-point units
  avgCost: Money;        // cost per unit in base currency (fixed)
  price: Money;          // current price per unit in base currency
  liquid: boolean;
  lockUntilDay: number;
  salePenalty: Money;    // fraction fixed (e.g. 0.005)
};

export type DebtState = {
  principal: Money;      // in debt currency
  apr: Money;            // fraction fixed (0.24)
  minPayDaily: Money;    // in debt currency
  currency: CurrencyCode;

  daysLate: number;
  onTimePayments: number;
};

export type MetricsState = {
  creditScore: number;          // 300..850 simple
  shockCount30: number;         // rolling-ish (simplified)
  lastBalanceBase: Money;
  vibe: string;
  pet: string;
};

export type EngineState = {
  day: number;
  baseCurrency: CurrencyCode;

  wallet: Wallet;               // balances per currency
  assets: AssetLot[];
  debt?: DebtState;

  realizedGainsTodayBase: Money;
  taxDueBase: Money;

  prngState: number;            // PRNG internal state (u32)
  metrics: MetricsState;
};

export type SimulationSeries = {
  day: number[];
  balanceBase: string[];
  navBase: string[];
  liquidityRatio: number[];
  creditScore: number[];
  walletValueBase: string[];
  vibe: string[];
  pet: string[];

  // ✅ NEW breakdown series
  assetValueBase: string[];          // total market value of assets
  debtPrincipal: string[];           // debt principal (in debt currency)
  realizedGainsTodayBase: string[];  // realized gains on that day
  taxDueBase: string[];              // unpaid tax remaining after payment
  rsi: number[]; // ✅ NEW: 0..100
};


export type SimulationResult = {
  series: SimulationSeries;
  finalBalanceBase: string;
  finalNavBase: string;         // ✅ add
  collapseDay: number | null;
};

export type AggregateOutput = {
  expectedFinalBalanceBase: string;
  p5FinalBalanceBase: string;
  p95FinalBalanceBase: string;

  expectedFinalNavBase: string;
  p5FinalNavBase: string;
  p95FinalNavBase: string;

  expectedFinalRsi: number; // ✅ NEW
  p5FinalRsi: number;       // ✅ NEW
  p95FinalRsi: number;      // ✅ NEW
  sampleFinalRsi: number; // ✅ NEW

  collapseProbability: number;
  collapseTimingDensity: Record<number, number>;

  sampleSeries: SimulationSeries;

  // ✅ NEW - makes frontend dead simple
  sampleFinalBalanceBase: string;
  sampleFinalNavBase: string;
  sampleCollapseDay: number | null;
};


