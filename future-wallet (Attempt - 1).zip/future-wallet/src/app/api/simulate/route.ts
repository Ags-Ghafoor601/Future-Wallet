import { NextResponse } from "next/server";
import { ScenarioSchema, runAggregate } from "@/lib/engine";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = ScenarioSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: "Invalid scenario", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const output = runAggregate(parsed.data);

    return NextResponse.json({ ok: true, output }, { status: 200 });
  } catch (e: any) {
    console.error("simulate error:", e);
    return NextResponse.json(
      { ok: false, error: e?.message ?? "Unknown error" },
      { status: 500 }
    );
  }
}
