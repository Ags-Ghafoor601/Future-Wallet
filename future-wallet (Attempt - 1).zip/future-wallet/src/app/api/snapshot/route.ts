import { NextResponse } from "next/server";
import { ScenarioSchema } from "@/lib/engine";
import { runSingleSimulation } from "@/lib/engine";
import { toSnapshot } from "@/lib/engine/serialize"; // ensure exported
import { Scenario } from "@/lib/engine/types";
import { initialStateFromScenario, simulateFromState } from "@/lib/engine/engine"; // see note below

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const parsed = ScenarioSchema.safeParse(body.scenario);
    if (!parsed.success) {
      return NextResponse.json({ ok: false, error: "Invalid scenario", details: parsed.error.flatten() }, { status: 400 });
    }

    const day = Number(body.day);
    if (!Number.isInteger(day) || day < 0 || day > parsed.data.horizonDays) {
      return NextResponse.json({ ok: false, error: "Invalid snapshot day" }, { status: 400 });
    }

    // Run just to `day`
    // You'll expose simulateFromState + initialStateFromScenario via exports (next step).
    const scn: Scenario = parsed.data;

    const runSeed = (scn.seed + (body.runIndex ?? 0)) >>> 0;
    const init = initialStateFromScenario(scn, runSeed);
    const sim = simulateFromState(scn, init, 0, day);

    const snap = toSnapshot(sim.finalState);
    return NextResponse.json({ ok: true, snapshot: snap, partialSeries: sim.series }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message ?? "Unknown error" }, { status: 500 });
  }
}
