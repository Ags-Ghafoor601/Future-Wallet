import { NextResponse } from "next/server";
import { ScenarioSchema } from "@/lib/engine";
import { fromSnapshot } from "@/lib/engine/serialize";
import { Scenario } from "@/lib/engine/types";
import { formatFixedDecimal } from "@/lib/engine/fixed";
import { computeNav, simulateFromState } from "@/lib/engine/engine";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const parsed = ScenarioSchema.safeParse(body.scenario);
    if (!parsed.success) {
      return NextResponse.json({ ok: false, error: "Invalid scenario", details: parsed.error.flatten() }, { status: 400 });
    }

    const scn: Scenario = parsed.data;
    const snap = body.snapshot;
    if (!snap) return NextResponse.json({ ok: false, error: "Missing snapshot" }, { status: 400 });

    const state = fromSnapshot(snap);

    // Resume from state.day (or state.day+1 depending on your convention)
    const startDay = state.day + 1;
if (startDay >= scn.horizonDays) {
  // nothing left to simulate
  const finalBal = state.wallet[state.baseCurrency] ?? 0n;
  const { nav: finalNav } = computeNav(state);
  return NextResponse.json({
    ok: true,
    resumedSeries: {
      day: [],
      balanceBase: [],
      navBase: [],
      liquidityRatio: [],
      creditScore: [],
      vibe: [],
      pet: [],
      walletValueBase: [],
      assetValueBase: [],
      debtPrincipal: [],
      realizedGainsTodayBase: [],
      taxDueBase: [],
      rsi: [],
    },
    finalBalanceBase: formatFixedDecimal(finalBal),
    finalNavBase: formatFixedDecimal(finalNav),
    collapseDay: null,
  });
}
    const sim = simulateFromState(scn, state, startDay, scn.horizonDays);

    const finalBal = sim.finalState.wallet[sim.finalState.baseCurrency] ?? 0n;
    const { nav: finalNav } = computeNav(sim.finalState);

    return NextResponse.json({
      ok: true,
      resumedSeries: sim.series,
      finalBalanceBase: formatFixedDecimal(finalBal),
      finalNavBase: formatFixedDecimal(finalNav),
      collapseDay: sim.collapseDay,
    }, { status: 200 });

  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message ?? "Unknown error" }, { status: 500 });
  }
}
