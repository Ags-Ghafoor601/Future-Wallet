export type Scenario = any;

export const PRESETS: { key: string; name: string; scenario: Scenario }[] = [
  {
    key: "basic",
    name: "Basic (sanity)",
    scenario: {
      baseCurrency: "USD",
      horizonDays: 60,
      runs: 25,
      seed: 12345,
      incomeDaily: [{ amount: "50.000000", currency: "USD" }],
      expenseDaily: [{ amount: "40.000000", currency: "USD" }],
      fxTableDaily: { "0": { "USD/PKR": "280.000000", "PKR/USD": "0.003571" } },
      debt: { principal: "2000.000000", apr: "0.240000", minPayDaily: "5.000000", currency: "USD" },
      assets: [{ name: "S&P-ish", quantity: "2.000000", priceStart: "500.000000", volatility: "0.020000", liquid: true, salePenalty: "0.005000" }],
      tax: { brackets: [{ upTo: "1000.000000", rate: "0.000000" }, { upTo: "10000.000000", rate: "0.100000" }, { upTo: "999999999.000000", rate: "0.200000" }] }
    }
  },
  {
    key: "vol",
    name: "Volatility (wow Monte Carlo)",
    scenario: {
      baseCurrency: "USD",
      horizonDays: 90,
      runs: 50,
      seed: 777,
      incomeDaily: [{ amount: "60.000000", currency: "USD" }],
      expenseDaily: [{ amount: "55.000000", currency: "USD" }],
      fxTableDaily: { "0": { "USD/PKR": "280.000000", "PKR/USD": "0.003571" } },
      debt: { principal: "1000.000000", apr: "0.180000", minPayDaily: "3.000000", currency: "USD" },
      assets: [
        { name: "Growth", quantity: "3.000000", priceStart: "300.000000", volatility: "0.050000", liquid: true, salePenalty: "0.010000" },
        { name: "Stable", quantity: "5.000000", priceStart: "100.000000", volatility: "0.010000", liquid: true, salePenalty: "0.002000" }
      ],
      tax: { brackets: [{ upTo: "999999999.000000", rate: "0.150000" }] }
    }
  },
  {
    key: "fx",
    name: "FX (multi-currency drift check)",
    scenario: {
      baseCurrency: "USD",
      horizonDays: 30,
      runs: 25,
      seed: 13579,
      incomeDaily: [{ amount: "2800.000000", currency: "PKR" }],
      expenseDaily: [{ amount: "5.000000", currency: "USD" }],
      fxTableDaily: { "0": { "USD/PKR": "280.000000", "PKR/USD": "0.003571" } },
      debt: { principal: "0.000000", apr: "0.000000", minPayDaily: "0.000000", currency: "USD" },
      assets: [{ name: "FXAsset", quantity: "1.000000", priceStart: "100.000000", volatility: "0.010000", liquid: true, salePenalty: "0.005000" }],
      tax: { brackets: [{ upTo: "999999999.000000", rate: "0.100000" }] }
    }
  }
];
