import { EngineState, AssetLot, DebtState, Money, Wallet } from "./types";
import { formatFixedDecimal, parseFixedDecimal, sortedKeys } from "./fixed";

export type Snapshot = {
  day: number;
  baseCurrency: string;
  prngState: number;

  wallet: Record<string, string>; // fixed string
  assets: Array<{
    name: string;
    quantity: string;
    avgCost: string;
    price: string;
    liquid: boolean;
    lockUntilDay: number;
    salePenalty: string;
  }>;
  debt?: {
    principal: string;
    apr: string;
    minPayDaily: string;
    currency: string;
    daysLate: number;
    onTimePayments: number;
  };

  realizedGainsTodayBase: string;
  taxDueBase: string;

  metrics: {
    creditScore: number;
    shockCount30: number;
    lastBalanceBase: string;
    vibe: string;
    pet: string;
  };
};

export function toSnapshot(s: EngineState): Snapshot {
  const w: Record<string, string> = {};
  for (const k of sortedKeys(s.wallet)) {
    w[String(k)] = formatFixedDecimal(s.wallet[String(k)] ?? 0n);
  }

  return {
    day: s.day,
    baseCurrency: s.baseCurrency,
    prngState: s.prngState,

    wallet: w,
    assets: s.assets.map((a) => ({
      name: a.name,
      quantity: formatFixedDecimal(a.quantity),
      avgCost: formatFixedDecimal(a.avgCost),
      price: formatFixedDecimal(a.price),
      liquid: a.liquid,
      lockUntilDay: a.lockUntilDay,
      salePenalty: formatFixedDecimal(a.salePenalty),
    })),
    debt: s.debt
      ? {
          principal: formatFixedDecimal(s.debt.principal),
          apr: formatFixedDecimal(s.debt.apr),
          minPayDaily: formatFixedDecimal(s.debt.minPayDaily),
          currency: s.debt.currency,
          daysLate: s.debt.daysLate,
          onTimePayments: s.debt.onTimePayments,
        }
      : undefined,

    realizedGainsTodayBase: formatFixedDecimal(s.realizedGainsTodayBase),
    taxDueBase: formatFixedDecimal(s.taxDueBase),

    metrics: {
      creditScore: s.metrics.creditScore,
      shockCount30: s.metrics.shockCount30,
      lastBalanceBase: formatFixedDecimal(s.metrics.lastBalanceBase),
      vibe: s.metrics.vibe,
      pet: s.metrics.pet,
    },
  };
}

export function fromSnapshot(sn: Snapshot): EngineState {
  const wallet: Wallet = {};
  for (const k of Object.keys(sn.wallet).sort()) {
    wallet[k] = parseFixedDecimal(sn.wallet[k]);
  }

  const assets: AssetLot[] = sn.assets.map((a) => ({
    name: a.name,
    quantity: parseFixedDecimal(a.quantity),
    avgCost: parseFixedDecimal(a.avgCost),
    price: parseFixedDecimal(a.price),
    liquid: a.liquid,
    lockUntilDay: a.lockUntilDay,
    salePenalty: parseFixedDecimal(a.salePenalty),
  }));

  const debt: DebtState | undefined = sn.debt
    ? {
        principal: parseFixedDecimal(sn.debt.principal),
        apr: parseFixedDecimal(sn.debt.apr),
        minPayDaily: parseFixedDecimal(sn.debt.minPayDaily),
        currency: sn.debt.currency,
        daysLate: sn.debt.daysLate,
        onTimePayments: sn.debt.onTimePayments,
      }
    : undefined;

  return {
    day: sn.day,
    baseCurrency: sn.baseCurrency,
    prngState: sn.prngState,
    wallet,
    assets,
    debt,
    realizedGainsTodayBase: parseFixedDecimal(sn.realizedGainsTodayBase),
    taxDueBase: parseFixedDecimal(sn.taxDueBase),
    metrics: {
      creditScore: sn.metrics.creditScore,
      shockCount30: sn.metrics.shockCount30,
      lastBalanceBase: parseFixedDecimal(sn.metrics.lastBalanceBase),
      vibe: sn.metrics.vibe,
      pet: sn.metrics.pet,
    },
  };
}
