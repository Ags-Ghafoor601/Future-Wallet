// FX is handled in engine helpers; this file exists for clarity.
// (We keep it minimal for the 2-hour build.)
export {};
