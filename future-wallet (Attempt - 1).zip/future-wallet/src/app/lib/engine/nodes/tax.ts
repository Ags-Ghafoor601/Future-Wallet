import { Node, Delta } from "./node";
import { EngineState, Scenario } from "../types";
import { addToWallet, parseFixedDecimal, mulFixed } from "../fixed";

export function TaxNode(scn: Scenario): Node {
  return {
    id: "tax",
    dependsOn: ["assets"],

    compute(prev: EngineState): Delta {
      const brackets = (scn.tax?.brackets ?? [
        { upTo: "1000.0", rate: "0.00" },
        { upTo: "10000.0", rate: "0.10" },
        { upTo: "999999999.0", rate: "0.20" },
      ]).map(b => ({ upTo: parseFixedDecimal(b.upTo), rate: parseFixedDecimal(b.rate) }));

      let gains = prev.realizedGainsTodayBase;
      if (gains <= 0n) {
        return { taxDueBase: 0n };
      }

      let tax = 0n;
      let remaining = gains;
      let prevCap = 0n;

      for (const b of brackets) {
        const cap = b.upTo;
        const band = cap - prevCap;
        if (band <= 0n) continue;

        const take = remaining > band ? band : remaining;
        if (take <= 0n) break;

        tax += mulFixed(take, b.rate);
        remaining -= take;
        prevCap = cap;
        if (remaining <= 0n) break;
      }

      // pay tax from base currency if possible (MVP)
      const wallet = { ...prev.wallet };
      const base = prev.baseCurrency;
      const avail = wallet[base] ?? 0n;
      const pay = avail >= tax ? tax : (avail > 0n ? avail : 0n);

      if (pay > 0n) addToWallet(wallet, base, -pay);

      return { taxDueBase: tax - pay, wallet };
    },
  };
}
