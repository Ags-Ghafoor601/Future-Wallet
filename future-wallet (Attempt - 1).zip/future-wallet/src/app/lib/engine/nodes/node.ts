import { EngineState } from "../types";

export type Delta = Partial<EngineState> & {
  // if node wants to mutate wallet/assets safely, it returns updated copies
};

export interface Node {
  id: string;
  dependsOn: string[];
  compute(prev: EngineState, ctx: { fxForDay: (pair: string) => string | null }): Delta;
}
