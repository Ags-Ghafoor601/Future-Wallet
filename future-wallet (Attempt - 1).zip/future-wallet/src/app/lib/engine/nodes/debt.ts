import { Node, Delta } from "./node";
import { EngineState, Scenario, SCALE } from "../types";
import { addToWallet, divFixed, mulFixed, parseFixedDecimal } from "../fixed";

export function DebtNode(scn: Scenario): Node {
  return {
    id: "debt",
    dependsOn: ["cashflow"],
    compute(prev: EngineState): Delta {
      if (!scn.debt || !prev.debt) return {};

      const debt = { ...prev.debt };
      const wallet = { ...prev.wallet };

      // daily interest = principal * apr / 365
      const dailyRate = divFixed(debt.apr, parseFixedDecimal("365.0")); // apr/365
      const interest = mulFixed(debt.principal, dailyRate);
      debt.principal += interest;

      // attempt min payment from wallet in debt currency
      const available = wallet[debt.currency] ?? 0n;
      const pay = available >= debt.minPayDaily ? debt.minPayDaily : (available > 0n ? available : 0n);

      if (pay > 0n) {
        addToWallet(wallet, debt.currency, -pay);
        debt.principal -= pay;

        // punctuality logic (simple)
        if (pay >= debt.minPayDaily) {
          debt.onTimePayments += 1;
          debt.daysLate = 0;
        } else {
          debt.daysLate += 1;
        }
      } else {
        debt.daysLate += 1;
      }

      if (debt.principal < 0n) debt.principal = 0n;

      return { debt, wallet };
    },
  };
}
