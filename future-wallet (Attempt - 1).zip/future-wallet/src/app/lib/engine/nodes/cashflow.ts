import { Node, Delta } from "./node";
import { EngineState, Scenario } from "../types";
import { addToWallet, parseFixedDecimal } from "../fixed";

export function CashflowNode(scn: Scenario): Node {
  return {
    id: "cashflow",
    dependsOn: [],
    compute(prev: EngineState): Delta {
      const wallet = { ...prev.wallet };

      for (const inc of scn.incomeDaily) {
        addToWallet(wallet, inc.currency, parseFixedDecimal(inc.amount));
      }
      for (const exp of scn.expenseDaily) {
        addToWallet(wallet, exp.currency, -parseFixedDecimal(exp.amount));
      }

      return { wallet };
    },
  };
}
