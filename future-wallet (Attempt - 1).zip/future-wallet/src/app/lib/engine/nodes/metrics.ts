import { Node, Delta } from "./node";
import { EngineState } from "../types";
import { parseFixedDecimal, formatFixedDecimal } from "../fixed";

export function MetricsNode(): Node {
  return {
    id: "metrics",
    dependsOn: ["tax"],

    compute(prev: EngineState): Delta {
      const m = { ...prev.metrics };

      const baseBal = prev.wallet[prev.baseCurrency] ?? 0n;

      // shock = base balance negative today
      const shock = baseBal < 0n ? 1 : 0;
      m.shockCount30 = Math.max(0, m.shockCount30 + shock - (prev.day % 30 === 0 ? 1 : 0)); // simple decay

      // credit score moves by punctuality
      if (prev.debt) {
        const latePenalty = Math.min(25, prev.debt.daysLate * 2);
        const onTimeBoost = Math.min(10, prev.debt.onTimePayments > 0 ? 1 : 0);
        m.creditScore = Math.max(300, Math.min(850, m.creditScore - latePenalty + onTimeBoost));
      } else {
        m.creditScore = Math.min(850, m.creditScore + 1); // no debt slowly improves
      }

      // vibe/pet mapping
      const balStr = formatFixedDecimal(baseBal);
      if (baseBal > parseFixedDecimal("10000.0")) {
        m.vibe = "Thriving";
        m.pet = "Phoenix";
      } else if (baseBal > parseFixedDecimal("1000.0")) {
        m.vibe = "Stable";
        m.pet = "Cat";
      } else if (baseBal >= 0n) {
        m.vibe = "Cautious";
        m.pet = "Turtle";
      } else if (baseBal > parseFixedDecimal("-1000.0")) {
        m.vibe = "Stressed";
        m.pet = "Hedgehog";
      } else {
        m.vibe = "Crisis";
        m.pet = "Axolotl";
      }

      m.lastBalanceBase = baseBal;

      return { metrics: m };
    },
  };
}
