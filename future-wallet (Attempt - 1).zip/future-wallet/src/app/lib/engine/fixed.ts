import { SCALE, Money } from "./types";

export function parseFixedDecimal(input: string, scale: bigint = SCALE): bigint {
  // supports "-123.456789"
  const s = input.trim();
  if (!s) throw new Error("Empty number");
  const neg = s.startsWith("-");
  const t = neg ? s.slice(1) : s;

  const [intPart, fracPartRaw] = t.split(".");
  const fracPart = (fracPartRaw ?? "").slice(0, 6).padEnd(6, "0"); // 6 dp
  const i = BigInt(intPart || "0");
  const f = BigInt(fracPart || "0");

  const val = i * scale + f;
  return neg ? -val : val;
}

export function formatFixedDecimal(x: bigint, scale: bigint = SCALE): string {
  const neg = x < 0n;
  const v = neg ? -x : x;
  const i = v / scale;
  const f = v % scale;

  const frac = f.toString().padStart(6, "0");
  return `${neg ? "-" : ""}${i.toString()}.${frac}`;
}

// Multiply two fixed numbers (a*b)/SCALE
export function mulFixed(a: bigint, b: bigint, scale: bigint = SCALE): bigint {
  return (a * b) / scale; // deterministic truncation (round down)
}

// Divide fixed numbers (a/b)*SCALE
export function divFixed(a: bigint, b: bigint, scale: bigint = SCALE): bigint {
  if (b === 0n) throw new Error("Division by zero");
  return (a * scale) / b; // deterministic truncation
}

// Clamp
export function clampMoney(x: Money, min: Money, max: Money): Money {
  if (x < min) return min;
  if (x > max) return max;
  return x;
}

// Safe add to wallet currency key
export function addToWallet(wallet: Record<string, bigint>, ccy: string, delta: bigint) {
  wallet[ccy] = (wallet[ccy] ?? 0n) + delta;
}

// Return sorted keys for deterministic iteration
export function sortedKeys<T extends object>(obj: T): (keyof T)[] {
  return (Object.keys(obj) as (keyof T)[]).sort((a, b) => String(a).localeCompare(String(b)));
}
