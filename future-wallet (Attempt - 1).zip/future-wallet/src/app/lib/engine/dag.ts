export type DagNode = { id: string; dependsOn: string[] };

export function topoSortStable(nodes: DagNode[]): string[] {
  const byId: Record<string, DagNode> = {};
  for (const n of nodes) byId[n.id] = n;

  // Build indegree + adjacency
  const indeg: Record<string, number> = {};
  const adj: Record<string, string[]> = {};

  for (const n of nodes) {
    indeg[n.id] = indeg[n.id] ?? 0;
    adj[n.id] = adj[n.id] ?? [];
  }

  for (const n of nodes) {
    for (const dep of n.dependsOn) {
      if (!byId[dep]) throw new Error(`Missing dependency: ${n.id} depends on ${dep}`);
      indeg[n.id] = (indeg[n.id] ?? 0) + 1;
      adj[dep].push(n.id);
    }
  }

  // Stable queue = lexicographically sorted IDs with indegree 0
  const zero: string[] = Object.keys(indeg).filter((k) => indeg[k] === 0).sort();

  const out: string[] = [];
  while (zero.length) {
    const id = zero.shift()!;
    out.push(id);

    const nexts = (adj[id] ?? []).slice().sort(); // stable iteration
    for (const v of nexts) {
      indeg[v] -= 1;
      if (indeg[v] === 0) {
        zero.push(v);
        zero.sort();
      }
    }
  }

  if (out.length !== nodes.length) {
    throw new Error("Dependency loop detected in DAG");
  }
  return out;
}
