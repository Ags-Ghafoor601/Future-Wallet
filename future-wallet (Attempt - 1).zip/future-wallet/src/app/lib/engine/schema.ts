import { z } from "zod";

const fxPair = z.string().regex(/^[A-Z]{3,}\/[A-Z]{3,}$/);

export const ScenarioSchema = z.object({
  baseCurrency: z.string().min(3),
  horizonDays: z.number().int().min(1).max(5000),
  runs: z.number().int().min(1).max(500),
  seed: z.number().int(),

  incomeDaily: z.array(z.object({
    amount: z.string(),
    currency: z.string().min(3),
  })).default([]),

  expenseDaily: z.array(z.object({
    amount: z.string(),
    currency: z.string().min(3),
  })).default([]),

  fxTableDaily: z.record(z.coerce.number(), z.record(fxPair, z.string())).default({}),

  debt: z.object({
    principal: z.string(),
    apr: z.string(),
    minPayDaily: z.string(),
    currency: z.string().min(3),
  }).optional(),

  assets: z.array(z.object({
    name: z.string().min(1),
    quantity: z.string(),
    priceStart: z.string(),
    volatility: z.string(),
    liquid: z.boolean(),
    lockUntilDay: z.number().int().optional(),
    salePenalty: z.string().optional(),
  })).optional(),

  tax: z.object({
    brackets: z.array(z.object({
      upTo: z.string(),
      rate: z.string(),
    })).optional(),
  }).optional(),
});
