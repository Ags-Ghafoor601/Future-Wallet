export function u32(n: number): number {
  return n >>> 0;
}

export function xorshift32(state: number): number {
  // returns next state (u32)
  let x = u32(state);
  x ^= u32(x << 13);
  x ^= u32(x >>> 17);
  x ^= u32(x << 5);
  return u32(x);
}

export function randU32(state: number): { state: number; value: number } {
  const ns = xorshift32(state || 2463534242);
  return { state: ns, value: ns };
}

export function randInt(state: number, min: number, max: number): { state: number; value: number } {
  // inclusive min..max
  const r = randU32(state);
  const span = max - min + 1;
  const v = min + (r.value % span);
  return { state: r.state, value: v };
}

export function rand01(state: number): { state: number; value: number } {
  // deterministic 0..1 using u32 / 2^32
  const r = randU32(state);
  return { state: r.state, value: r.value / 4294967296 };
}
