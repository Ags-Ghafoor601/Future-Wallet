import {
  AggregateOutput,
  EngineState,
  Scenario,
  SimulationResult,
  SimulationSeries,
  SCALE,
  AssetLot,
} from "./types";
import { parseFixedDecimal, formatFixedDecimal, addToWallet, mulFixed, divFixed } from "./fixed";
import { topoSortStable } from "./dag";
import { randU32 } from "./prng";

import { CashflowNode } from "./nodes/cashflow";
import { DebtNode } from "./nodes/debt";
import { AssetsNode } from "./nodes/assets";
import { TaxNode } from "./nodes/tax";
import { MetricsNode } from "./nodes/metrics";
import type { Node, Delta } from "./nodes/node";

function fxLookup(scn: Scenario, day: number, pair: string): string | null {
  const table = scn.fxTableDaily[day] ?? scn.fxTableDaily[0] ?? {};
  return (table as any)[pair] ?? null;
}

// Convert money from `from` currency to `to` currency at given day using FX table.
// Uses pair "FROM/TO" if present; else tries inverse "TO/FROM".
function convert(
  scn: Scenario,
  day: number,
  amount: bigint,
  from: string,
  to: string
): bigint {
  if (from === to) return amount;
  const p1 = `${from}/${to}`;
  const r1 = fxLookup(scn, day, p1);
  if (r1) {
    const rate = parseFixedDecimal(r1); // to per from
    return mulFixed(amount, rate);      // amount(from) * rate = amount(to)
  }
  const p2 = `${to}/${from}`;
  const r2 = fxLookup(scn, day, p2);
  if (r2) {
    const inv = parseFixedDecimal(r2);  // from per to
    // amount(to) = amount(from) / inv
    return divFixed(amount, inv);
  }
  throw new Error(`Missing FX rate for ${from}<->${to} on day ${day}`);
}

// Compute base NAV and liquidity ratio (liquid assets / total nav)
function computeNav(state: EngineState): { nav: bigint; liquidityRatio: number } {
  const base = state.baseCurrency;
  const baseCash = state.wallet[base] ?? 0n;

  let assetsValue = 0n;
  let liquidValue = 0n;

  for (const a of state.assets) {
    const v = mulFixed(a.quantity, a.price);
    assetsValue += v;
    if (a.liquid && state.day >= a.lockUntilDay) liquidValue += v;
  }

  const nav = baseCash + assetsValue;
  const ratio = nav === 0n ? 0 : Number(liquidValue) / Number(nav); // for UI only
  return { nav, liquidityRatio: isFinite(ratio) ? ratio : 0 };
}

// Deterministic forced liquidation that also records realized gains for TaxNode.
function forcedLiquidationWithGains(state: EngineState): EngineState {
  const base = state.baseCurrency;
  let baseCash = state.wallet[base] ?? 0n;
  if (baseCash >= 0n) return state;

  const assets = state.assets.map(a => ({ ...a }));
  const wallet = { ...state.wallet };

  let realized = 0n;

  const order = assets.slice().sort((x, y) => x.name.localeCompare(y.name));
  for (const a of order) {
    if (baseCash >= 0n) break;
    if (!a.liquid) continue;
    if (state.day < a.lockUntilDay) continue;
    if (a.quantity <= 0n) continue;

    const penaltyFactor = parseFixedDecimal("1.0") - a.salePenalty;
    const effectivePrice = mulFixed(a.price, penaltyFactor);
    if (effectivePrice <= 0n) continue;

    const deficit = -baseCash;

    // qtyNeeded = deficit / effectivePrice (ceil-ish handled by trunc + min)
    let qtyNeeded = divFixed(deficit, effectivePrice);
    if (qtyNeeded <= 0n) qtyNeeded = parseFixedDecimal("0.000001"); // minimal sell
    const sellQty = qtyNeeded >= a.quantity ? a.quantity : qtyNeeded;

    // proceeds
    const proceeds = mulFixed(sellQty, effectivePrice);
    addToWallet(wallet, base, proceeds);
    baseCash += proceeds;

    // realized gains (ignore penalty for cost basis; good enough for MVP)
    const gainPerUnit = a.price - a.avgCost;
    const gain = mulFixed(sellQty, gainPerUnit);
    realized += gain;

    a.quantity -= sellQty;
  }

  // Rebuild assets array in deterministic order (name asc)
  const assetsSorted = assets.slice().sort((x, y) => x.name.localeCompare(y.name));

  return {
    ...state,
    wallet,
    assets: assetsSorted,
    realizedGainsTodayBase: state.realizedGainsTodayBase + realized,
  };
}

function initialStateFromScenario(scn: Scenario, runSeed: number): EngineState {
  const wallet: Record<string, bigint> = {};
  wallet[scn.baseCurrency] = 0n;

  const assets: AssetLot[] = (scn.assets ?? []).map((a) => ({
    name: a.name,
    quantity: parseFixedDecimal(a.quantity),
    avgCost: parseFixedDecimal(a.priceStart),
    price: parseFixedDecimal(a.priceStart),
    liquid: a.liquid,
    lockUntilDay: a.lockUntilDay ?? 0,
    salePenalty: parseFixedDecimal(a.salePenalty ?? "0.005"),
  })).sort((x, y) => x.name.localeCompare(y.name));

  const debt = scn.debt
    ? {
        principal: parseFixedDecimal(scn.debt.principal),
        apr: parseFixedDecimal(scn.debt.apr),
        minPayDaily: parseFixedDecimal(scn.debt.minPayDaily),
        currency: scn.debt.currency,
        daysLate: 0,
        onTimePayments: 0,
      }
    : undefined;

  return {
    day: 0,
    baseCurrency: scn.baseCurrency,
    wallet,
    assets,
    debt,
    realizedGainsTodayBase: 0n,
    taxDueBase: 0n,
    prngState: runSeed >>> 0,
    metrics: {
      creditScore: 650,
      shockCount30: 0,
      lastBalanceBase: 0n,
      vibe: "Cautious",
      pet: "Turtle",
    },
  };
}

function buildNodes(scn: Scenario): Node[] {
  // minimal deterministic DAG
  return [
    CashflowNode(scn),
    DebtNode(scn),
    AssetsNode(scn),
    TaxNode(scn),
    MetricsNode(),
  ];
}

function applyDelta(prev: EngineState, delta: Delta): EngineState {
  // two-phase commit: merge shallow copies
  return {
    ...prev,
    ...delta,
    wallet: delta.wallet ?? prev.wallet,
    assets: delta.assets ?? prev.assets,
    debt: delta.debt ?? prev.debt,
    metrics: delta.metrics ?? prev.metrics,
    prngState: delta.prngState ?? prev.prngState,
    realizedGainsTodayBase: delta.realizedGainsTodayBase ?? prev.realizedGainsTodayBase,
    taxDueBase: delta.taxDueBase ?? prev.taxDueBase,
  };
}

export function runSingleSimulation(scn: Scenario, runIndex: number): SimulationResult {
  const runSeed = (scn.seed + runIndex) >>> 0;

  const nodes = buildNodes(scn);
  const order = topoSortStable(nodes.map(n => ({ id: n.id, dependsOn: n.dependsOn })));
  const nodeMap: Record<string, Node> = {};
  for (const n of nodes) nodeMap[n.id] = n;

  let state = initialStateFromScenario(scn, runSeed);

  const series: SimulationSeries = {
    day: [],
    balanceBase: [],
    navBase: [],
    liquidityRatio: [],
    creditScore: [],
    vibe: [],
    pet: [],
  };

  let collapseDay: number | null = null;

  for (let day = 0; day < scn.horizonDays; day++) {
    state = { ...state, day, realizedGainsTodayBase: 0n };

    // Deterministic "fxForDay" helper
    const fxForDay = (pair: string) => fxLookup(scn, day, pair);

    // Execute DAG nodes
    let next = state;
    for (const id of order) {
      const node = nodeMap[id];
      const delta = node.compute(next, { fxForDay });
      next = applyDelta(next, delta);
    }

    // Convert all non-base wallet balances into base for “net” checks? (MVP)
    // We'll keep balances in their own currencies; collapse checks use base only.

    // Forced liquidation + realized gains alignment
    next = forcedLiquidationWithGains(next);

    // Compute tax after liquidation gains as well (one more deterministic pass)
    // (Keeps tax aligned to realized gains)
    const taxNode = buildNodes(scn).find(n => n.id === "tax")!;
    next = applyDelta(next, taxNode.compute(next, { fxForDay }));

    // Collapse condition: base cash < -1000
    const baseBal = next.wallet[next.baseCurrency] ?? 0n;
    if (collapseDay === null && baseBal < parseFixedDecimal("-1000.0")) {
      collapseDay = day;
    }

    const { nav, liquidityRatio } = computeNav(next);

    series.day.push(day);
    series.balanceBase.push(formatFixedDecimal(baseBal));
    series.navBase.push(formatFixedDecimal(nav));
    series.liquidityRatio.push(liquidityRatio);
    series.creditScore.push(next.metrics.creditScore);
    series.vibe.push(next.metrics.vibe);
    series.pet.push(next.metrics.pet);

    state = next;
  }

  const finalBal = state.wallet[state.baseCurrency] ?? 0n;

  return {
    series,
    finalBalanceBase: formatFixedDecimal(finalBal),
    collapseDay,
  };
}

export function runAggregate(scn: Scenario): AggregateOutput {
  const results: SimulationResult[] = [];
  for (let i = 0; i < scn.runs; i++) {
    results.push(runSingleSimulation(scn, i));
  }

  // final balances -> sort deterministically
  const finals = results.map(r => parseFixedDecimal(r.finalBalanceBase));
  const sorted = finals.slice().sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));

  const mean = sorted.reduce((acc, x) => acc + x, 0n) / BigInt(sorted.length);

  const p5 = sorted[Math.floor(0.05 * (sorted.length - 1))];
  const p95 = sorted[Math.floor(0.95 * (sorted.length - 1))];

  // collapse stats
  const collapseCount = results.filter(r => r.collapseDay !== null).length;
  const density: Record<number, number> = {};
  for (const r of results) {
    if (r.collapseDay !== null) {
      density[r.collapseDay] = (density[r.collapseDay] ?? 0) + 1;
    }
  }

  return {
    expectedFinalBalanceBase: formatFixedDecimal(mean),
    p5FinalBalanceBase: formatFixedDecimal(p5),
    p95FinalBalanceBase: formatFixedDecimal(p95),
    collapseProbability: collapseCount / results.length,
    collapseTimingDensity: density,
    sampleSeries: results[0].series,
  };
}
