import type { Config } from "tailwindcss";

export default {
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      boxShadow: {
        neon: "0 0 0 1px rgba(0,255,209,.18), 0 0 24px rgba(0,255,209,.16), 0 0 64px rgba(147,51,234,.12)",
      },
      backgroundImage: {
        "grid-glow":
          "radial-gradient(900px circle at 15% 15%, rgba(0,255,209,0.10), transparent 60%), radial-gradient(700px circle at 85% 20%, rgba(147,51,234,0.14), transparent 55%), radial-gradient(900px circle at 50% 85%, rgba(59,130,246,0.10), transparent 60%)",
      },
    },
  },
  plugins: [],
} satisfies Config;
